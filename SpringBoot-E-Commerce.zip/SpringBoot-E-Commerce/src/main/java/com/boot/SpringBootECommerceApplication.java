package com.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootECommerceApplication 
{

	public static void main(String[] args) 
	{
		SpringApplication.run(SpringBootECommerceApplication.class, args);
	}

}



package com.boot.entity;

import javax.persistence.*;


@Entity
public class Favourite {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column
	private String userEmail;
	
	@Column
	private long productId;
	
	@Column
	private String imgUrl;
	
	@Column
	private String productName;
	
	@Column
	private String price;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Favourite [id=" + id + ", userEmail=" + userEmail + ", productId=" + productId + ", imgUrl=" + imgUrl
				+ ", productName=" + productName + ", price=" + price + "]";
	}

	public Favourite() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}

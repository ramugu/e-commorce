package com.boot.entity;

import javax.persistence.*;


@Entity
public class ProductEntity 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long productId;
	
	@Column
	private String productImgUrl;
	@Column
	private String productPart;
	
	@Column
	private String productName;
	
	@Column
	private int model;
	
	@Column
	private String brand;
	
	@Column
	private int price;
	
	@Column
	private int noOfStack;
	
	@Column
	private String productRating;
	
	@Column
	private String productWaranty;

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getProductImgUrl() {
		return productImgUrl;
	}

	public void setProductImgUrl(String productImgUrl) {
		this.productImgUrl = productImgUrl;
	}

	public String getProductPart() {
		return productPart;
	}

	public void setProductPart(String productPart) {
		this.productPart = productPart;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getModel() {
		return model;
	}

	public void setModel(int model) {
		this.model = model;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getNoOfStack() {
		return noOfStack;
	}

	public void setNoOfStack(int noOfStack) {
		this.noOfStack = noOfStack;
	}

	public String getProductRating() {
		return productRating;
	}

	public void setProductRating(String productRating) {
		this.productRating = productRating;
	}

	public String getProductWaranty() {
		return productWaranty;
	}

	public void setProductWaranty(String productWaranty) {
		this.productWaranty = productWaranty;
	}

	@Override
	public String toString() {
		return "ProductEntity [productId=" + productId + ", productImgUrl=" + productImgUrl + ", productPart="
				+ productPart + ", productName=" + productName + ", model=" + model + ", brand=" + brand + ", price="
				+ price + ", noOfStack=" + noOfStack + ", productRating=" + productRating + ", productWaranty="
				+ productWaranty + "]";
	}

	public ProductEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}


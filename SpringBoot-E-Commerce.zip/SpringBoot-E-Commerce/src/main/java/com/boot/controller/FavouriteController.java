package com.boot.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.entity.Favourite;
import com.boot.service.FavouriteService;

@CrossOrigin("*")
@RestController
@RequestMapping("/favourite")
public class FavouriteController {

	private FavouriteService service;
	
	public FavouriteController(FavouriteService service) {
		super();
		this.service = service;
	}


	@PostMapping("add")
	public ResponseEntity<Favourite> addFavourite(@RequestBody Favourite favourite) 
	{
		return new ResponseEntity<Favourite>(service.addFavourite(favourite),HttpStatus.CREATED);
	}

	@GetMapping("/email/{email}")
	public ResponseEntity<List<Favourite>> getAllFavoriteByEmail(@PathVariable("email") String email)
	{
		
		return new ResponseEntity<List<Favourite>>(service.getAllFavoriteByEmail(email),HttpStatus.OK);
	}

	@GetMapping("/id/{id}")
	public ResponseEntity<Favourite> getFavoriteById(@PathVariable("id") long id) 
	{
	
		return new ResponseEntity<Favourite>(service.getFavoriteById(id),HttpStatus.OK);
	}
	
	@DeleteMapping("/{id}")
	public void deleteFavouriteById(@PathVariable("id") long id) 
	{
	
		service.deleteFavouriteById(id);
	}
}

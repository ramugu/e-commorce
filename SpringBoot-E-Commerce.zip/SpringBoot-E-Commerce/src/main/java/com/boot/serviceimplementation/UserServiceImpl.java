package com.boot.serviceimplementation;

import org.springframework.stereotype.Service;

import com.boot.entity.UserEntity;
import com.boot.repository.UserRepository;
import com.boot.service.UserService;

@Service
public class UserServiceImpl implements UserService
{
	private UserRepository userRepository;
	
	
	public UserServiceImpl(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}

	@Override
	public UserEntity addStudentData(UserEntity userEntity) 
	{	
		return userRepository.save(userEntity);
	}

	@Override
	public UserEntity getUserById(String userName) 
	{	
		return userRepository.findById(userName).get();
	}

	@Override
	public boolean loginDemo(String userName, String userPassword)
	{
		boolean result;
		
		if(userRepository.existsById(userName))
		{
			String password = userRepository.findUserPassword(userName);
			if(password.equals(userPassword))
			{
				result=true;
			}
			else
			{
				result=false;
				
			}
		}
		else
		{
			result=false;
			
			
		}
		
		return result;
	}

	@Override
	public UserEntity getUserByEmail(String userEmail) 
	{
	
		return userRepository.getUserByEmail(userEmail);
	}

	@Override
	public UserEntity updatePassword(String email,UserEntity userEntity) 
	{
		return userRepository.save(userEntity);
	}

	

	
	

}

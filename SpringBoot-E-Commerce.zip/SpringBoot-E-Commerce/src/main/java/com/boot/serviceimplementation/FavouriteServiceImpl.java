package com.boot.serviceimplementation;

import java.util.List;

import org.springframework.stereotype.Service;

import com.boot.entity.Favourite;
import com.boot.repository.FavouriteRepository;
import com.boot.service.FavouriteService;

@Service
public class FavouriteServiceImpl implements FavouriteService{

	private FavouriteRepository repository;
	
	public FavouriteServiceImpl(FavouriteRepository repository) {
		super();
		this.repository = repository;
	}

	@Override
	public Favourite addFavourite(Favourite favourite) 
	{
		
		return repository.save(favourite);
	}

	@Override
	public List<Favourite> getAllFavoriteByEmail(String email)
	{
		
		return repository.getFavouriteByEmail(email);
	}

	@Override
	public Favourite getFavoriteById(long id) 
	{
	
		return repository.findById(id).get();
	}

	@Override
	public void deleteFavouriteById(long id) 
	{
	
		repository.deleteById(id);
	}

}

package com.boot.serviceimplementation;

import java.util.List;

import org.springframework.stereotype.Service;

import com.boot.entity.UserInfoEntity;
import com.boot.repository.UserInfoRepository;
import com.boot.service.UserInfoService;

@Service
public class UserInfoServiceImpl implements UserInfoService
{
	private UserInfoRepository userInfoRepository;
	
	public UserInfoServiceImpl(UserInfoRepository userInfoRepository) {
		super();
		this.userInfoRepository = userInfoRepository;
	}

	@Override
	public UserInfoEntity addUserInfo(UserInfoEntity userInfo) 
	{
		return userInfoRepository.save(userInfo);
	}

	@Override
	public UserInfoEntity getuserInfoById(long userId) 
	{
		return userInfoRepository.findById(userId).get();
	}

	@Override
	public UserInfoEntity updateUserInfoById(long userId, UserInfoEntity userInfo)
	{	
		return userInfoRepository.save(userInfo);
	}

	@Override
	public UserInfoEntity getUserInfoByEmail(String userEmail) 
	{
		return userInfoRepository.findUserByEmail(userEmail);
	}

	@Override
	public List<UserInfoEntity> getAllUserByProductId(long productId) 
	{
		return userInfoRepository.getAllUserByProductId(productId);
	}

}

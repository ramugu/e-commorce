package com.boot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.boot.entity.BuyProductEntity;


public interface BuyProductRepository extends JpaRepository<BuyProductEntity, Long>
{
	@Query(value="select*from buy_product_entity where user_email=:email",nativeQuery = true)
    public List<BuyProductEntity> findAllByEmail(@Param("email") String userEmail);
	
	@Query(value="select*from buy_product_entity where product_id=:id",nativeQuery = true)
    public List<BuyProductEntity> findAllByProductId(@Param("id") long productId);
	
	
}

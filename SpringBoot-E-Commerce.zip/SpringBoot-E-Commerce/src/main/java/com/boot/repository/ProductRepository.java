package com.boot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.boot.entity.ProductEntity;


public interface ProductRepository extends JpaRepository<ProductEntity, Long>
{
	@Query(value="select*from product_entity where product_id=:id",nativeQuery = true)
    public ProductEntity getProductsByProductId(@Param("id") long productId);
	
	@Query(value="select distinct product_id from buy_product_entity ",nativeQuery = true)
    public Long[] getAllProductId();
	
	@Query(value="select * from product_entity where product_name like :serch%",nativeQuery = true)
	public List<ProductEntity> getAllProductBySerch(@Param("serch") String productName);
}

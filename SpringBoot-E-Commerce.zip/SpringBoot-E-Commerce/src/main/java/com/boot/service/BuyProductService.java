package com.boot.service;

import java.util.List;

import com.boot.entity.BuyProductEntity;

public interface BuyProductService 
{
	//addBuyProduct
	public BuyProductEntity addBuyProduct(BuyProductEntity buyProduct);
	
	//getBuyProductById
	public BuyProductEntity getBuyProductById(long id);
	
	//deleteBuyProductById
	public String deleteBuyProductById(long id);
	
	//getBuyProductByEmail
	public List<BuyProductEntity> getBuyProductByEmail(String userEmail);
	
	//getBuyProductByProductId
	public List<BuyProductEntity> getBuyProductByProductId(long productId);
	
	
}

package com.boot.service;

import java.util.List;

import com.boot.entity.UserInfoEntity;

public interface UserInfoService 
{
	//add user info method
	public UserInfoEntity addUserInfo(UserInfoEntity userInfo);
	
	//get User By Id method
	public UserInfoEntity getuserInfoById(long userId);
	
	//update User Info By Id
	public UserInfoEntity updateUserInfoById(long userId,UserInfoEntity userInfo);
	
	
	//get  User By email
	public UserInfoEntity getUserInfoByEmail(String userEmail);
	
	//getAllUserByProductId
	public List<UserInfoEntity> getAllUserByProductId(long productId);
	
	
}

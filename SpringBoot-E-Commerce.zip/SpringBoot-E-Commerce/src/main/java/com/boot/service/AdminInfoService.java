package com.boot.service;

import java.util.List;

import com.boot.entity.AdminInfo;

public interface AdminInfoService {
	//update Admin
	public AdminInfo updateAdmin(AdminInfo admin);
	
	//getAdminInfoById
	public AdminInfo getAdminInfoId(long id);
	
	//getAllAdminInfo
	public List<AdminInfo> getAllAdmin();

}

export class ProductInfo
{
    productId!:number;
	productImgUrl!:string;
    productPart!:string;//catagory
	productName!:string;
	model!:number;
	brand!:string;
	price!:number;
	noOfStack!:number;
	productRating!:string;
	productWaranty!:string;
}

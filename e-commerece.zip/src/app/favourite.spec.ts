import { Favourite } from './favourite';

describe('Favourite', () => {
  it('should create an instance', () => {
    expect(new Favourite()).toBeTruthy();
  });
});

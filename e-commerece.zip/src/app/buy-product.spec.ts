import { BuyProduct } from './buy-product';

describe('BuyProduct', () => {
  it('should create an instance', () => {
    expect(new BuyProduct()).toBeTruthy();
  });
});

import { PaymentConfirm } from './payment-confirm';

describe('PaymentConfirm', () => {
  it('should create an instance', () => {
    expect(new PaymentConfirm()).toBeTruthy();
  });
});
